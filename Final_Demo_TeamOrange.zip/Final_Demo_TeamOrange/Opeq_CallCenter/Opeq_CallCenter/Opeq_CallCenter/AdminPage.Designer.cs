﻿namespace Opeq_CallCenter
{
    partial class AdminPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminPage));
            this.actionTookAddBtn = new System.Windows.Forms.Button();
            this.actionTookRemoveBtn = new System.Windows.Forms.Button();
            this.actionTookTextBox = new System.Windows.Forms.TextBox();
            this.actionTookComboBox = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.orderTypeAddBtn = new System.Windows.Forms.Button();
            this.orderTypeRemoveBtn = new System.Windows.Forms.Button();
            this.orderTypeTextBox = new System.Windows.Forms.TextBox();
            this.orderTypeComboBox = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.phoneOrTabProbAddBtn = new System.Windows.Forms.Button();
            this.phoneOrTabProbRemoveBtn = new System.Windows.Forms.Button();
            this.laptopProbAddBtn = new System.Windows.Forms.Button();
            this.laptopProbRemoveBtn = new System.Windows.Forms.Button();
            this.screenProbAddBtn = new System.Windows.Forms.Button();
            this.screenProbRemoveBtn = new System.Windows.Forms.Button();
            this.computerProbAddBtn = new System.Windows.Forms.Button();
            this.computerProbRemoveBtn = new System.Windows.Forms.Button();
            this.phoneOrTabTextBox = new System.Windows.Forms.TextBox();
            this.laptopProbTextBox = new System.Windows.Forms.TextBox();
            this.computerProbTextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.phoneOrTabletProblemComboBox = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.laptopProblemComboBox = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.screenProblemComboBox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.computerProblemComboBox = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.adminRadioBtn = new System.Windows.Forms.RadioButton();
            this.viewRadioBtn = new System.Windows.Forms.RadioButton();
            this.modifyRadioBtn = new System.Windows.Forms.RadioButton();
            this.addButton = new System.Windows.Forms.RadioButton();
            this.screenProbTextBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // actionTookAddBtn
            // 
            this.actionTookAddBtn.BackColor = System.Drawing.Color.Green;
            resources.ApplyResources(this.actionTookAddBtn, "actionTookAddBtn");
            this.actionTookAddBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.actionTookAddBtn.Name = "actionTookAddBtn";
            this.actionTookAddBtn.UseVisualStyleBackColor = false;
            this.actionTookAddBtn.Click += new System.EventHandler(this.actionTookAddBtn_Click);
            // 
            // actionTookRemoveBtn
            // 
            this.actionTookRemoveBtn.BackColor = System.Drawing.Color.Red;
            resources.ApplyResources(this.actionTookRemoveBtn, "actionTookRemoveBtn");
            this.actionTookRemoveBtn.ForeColor = System.Drawing.SystemColors.Control;
            this.actionTookRemoveBtn.Name = "actionTookRemoveBtn";
            this.actionTookRemoveBtn.UseVisualStyleBackColor = false;
            this.actionTookRemoveBtn.Click += new System.EventHandler(this.actionTookRemoveBtn_Click);
            // 
            // actionTookTextBox
            // 
            resources.ApplyResources(this.actionTookTextBox, "actionTookTextBox");
            this.actionTookTextBox.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.actionTookTextBox.Name = "actionTookTextBox";
            this.actionTookTextBox.Click += new System.EventHandler(this.computerProbAddBtn_Click);
            this.actionTookTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.actionTookTextBox_MouseClick);
            // 
            // actionTookComboBox
            // 
            resources.ApplyResources(this.actionTookComboBox, "actionTookComboBox");
            this.actionTookComboBox.FormattingEnabled = true;
            this.actionTookComboBox.Name = "actionTookComboBox";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // orderTypeAddBtn
            // 
            this.orderTypeAddBtn.BackColor = System.Drawing.Color.Green;
            resources.ApplyResources(this.orderTypeAddBtn, "orderTypeAddBtn");
            this.orderTypeAddBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.orderTypeAddBtn.Name = "orderTypeAddBtn";
            this.orderTypeAddBtn.UseVisualStyleBackColor = false;
            this.orderTypeAddBtn.Click += new System.EventHandler(this.orderTypeAddBtn_Click);
            // 
            // orderTypeRemoveBtn
            // 
            this.orderTypeRemoveBtn.BackColor = System.Drawing.Color.Red;
            resources.ApplyResources(this.orderTypeRemoveBtn, "orderTypeRemoveBtn");
            this.orderTypeRemoveBtn.ForeColor = System.Drawing.SystemColors.Control;
            this.orderTypeRemoveBtn.Name = "orderTypeRemoveBtn";
            this.orderTypeRemoveBtn.UseVisualStyleBackColor = false;
            this.orderTypeRemoveBtn.Click += new System.EventHandler(this.orderTypeRemoveBtn_Click);
            // 
            // orderTypeTextBox
            // 
            resources.ApplyResources(this.orderTypeTextBox, "orderTypeTextBox");
            this.orderTypeTextBox.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.orderTypeTextBox.Name = "orderTypeTextBox";
            this.orderTypeTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.orderTypeTextBox_MouseClick);
            // 
            // orderTypeComboBox
            // 
            resources.ApplyResources(this.orderTypeComboBox, "orderTypeComboBox");
            this.orderTypeComboBox.FormattingEnabled = true;
            this.orderTypeComboBox.Name = "orderTypeComboBox";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // phoneOrTabProbAddBtn
            // 
            this.phoneOrTabProbAddBtn.BackColor = System.Drawing.Color.Green;
            resources.ApplyResources(this.phoneOrTabProbAddBtn, "phoneOrTabProbAddBtn");
            this.phoneOrTabProbAddBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.phoneOrTabProbAddBtn.Name = "phoneOrTabProbAddBtn";
            this.phoneOrTabProbAddBtn.UseVisualStyleBackColor = false;
            this.phoneOrTabProbAddBtn.Click += new System.EventHandler(this.phoneOrTabProbAddBtn_Click);
            // 
            // phoneOrTabProbRemoveBtn
            // 
            this.phoneOrTabProbRemoveBtn.BackColor = System.Drawing.Color.Red;
            resources.ApplyResources(this.phoneOrTabProbRemoveBtn, "phoneOrTabProbRemoveBtn");
            this.phoneOrTabProbRemoveBtn.ForeColor = System.Drawing.SystemColors.Control;
            this.phoneOrTabProbRemoveBtn.Name = "phoneOrTabProbRemoveBtn";
            this.phoneOrTabProbRemoveBtn.UseVisualStyleBackColor = false;
            this.phoneOrTabProbRemoveBtn.Click += new System.EventHandler(this.phoneOrTabProbRemoveBtn_Click);
            // 
            // laptopProbAddBtn
            // 
            this.laptopProbAddBtn.BackColor = System.Drawing.Color.Green;
            resources.ApplyResources(this.laptopProbAddBtn, "laptopProbAddBtn");
            this.laptopProbAddBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.laptopProbAddBtn.Name = "laptopProbAddBtn";
            this.laptopProbAddBtn.UseVisualStyleBackColor = false;
            this.laptopProbAddBtn.Click += new System.EventHandler(this.laptopProbAddBtn_Click);
            // 
            // laptopProbRemoveBtn
            // 
            this.laptopProbRemoveBtn.BackColor = System.Drawing.Color.Red;
            resources.ApplyResources(this.laptopProbRemoveBtn, "laptopProbRemoveBtn");
            this.laptopProbRemoveBtn.ForeColor = System.Drawing.SystemColors.Control;
            this.laptopProbRemoveBtn.Name = "laptopProbRemoveBtn";
            this.laptopProbRemoveBtn.UseVisualStyleBackColor = false;
            this.laptopProbRemoveBtn.Click += new System.EventHandler(this.laptopProbRemoveBtn_Click);
            // 
            // screenProbAddBtn
            // 
            this.screenProbAddBtn.BackColor = System.Drawing.Color.Green;
            resources.ApplyResources(this.screenProbAddBtn, "screenProbAddBtn");
            this.screenProbAddBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.screenProbAddBtn.Name = "screenProbAddBtn";
            this.screenProbAddBtn.UseVisualStyleBackColor = false;
            this.screenProbAddBtn.Click += new System.EventHandler(this.screenProbAddBtn_Click);
            // 
            // screenProbRemoveBtn
            // 
            this.screenProbRemoveBtn.BackColor = System.Drawing.Color.Red;
            resources.ApplyResources(this.screenProbRemoveBtn, "screenProbRemoveBtn");
            this.screenProbRemoveBtn.ForeColor = System.Drawing.SystemColors.Control;
            this.screenProbRemoveBtn.Name = "screenProbRemoveBtn";
            this.screenProbRemoveBtn.UseVisualStyleBackColor = false;
            this.screenProbRemoveBtn.Click += new System.EventHandler(this.screenProbRemoveBtn_Click);
            // 
            // computerProbAddBtn
            // 
            this.computerProbAddBtn.BackColor = System.Drawing.Color.Green;
            resources.ApplyResources(this.computerProbAddBtn, "computerProbAddBtn");
            this.computerProbAddBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.computerProbAddBtn.Name = "computerProbAddBtn";
            this.computerProbAddBtn.UseVisualStyleBackColor = false;
            // 
            // computerProbRemoveBtn
            // 
            this.computerProbRemoveBtn.BackColor = System.Drawing.Color.Red;
            resources.ApplyResources(this.computerProbRemoveBtn, "computerProbRemoveBtn");
            this.computerProbRemoveBtn.ForeColor = System.Drawing.SystemColors.Control;
            this.computerProbRemoveBtn.Name = "computerProbRemoveBtn";
            this.computerProbRemoveBtn.UseVisualStyleBackColor = false;
            this.computerProbRemoveBtn.Click += new System.EventHandler(this.computerProbRemoveBtn_Click);
            // 
            // phoneOrTabTextBox
            // 
            resources.ApplyResources(this.phoneOrTabTextBox, "phoneOrTabTextBox");
            this.phoneOrTabTextBox.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.phoneOrTabTextBox.Name = "phoneOrTabTextBox";
            this.phoneOrTabTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.phoneOrTabTextBox_MouseClick);
            // 
            // laptopProbTextBox
            // 
            resources.ApplyResources(this.laptopProbTextBox, "laptopProbTextBox");
            this.laptopProbTextBox.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.laptopProbTextBox.Name = "laptopProbTextBox";
            this.laptopProbTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.laptopProbTextBox_MouseClick);
            // 
            // computerProbTextBox
            // 
            resources.ApplyResources(this.computerProbTextBox, "computerProbTextBox");
            this.computerProbTextBox.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.computerProbTextBox.Name = "computerProbTextBox";
            this.computerProbTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.computerProbTextBox_MouseClick);
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // phoneOrTabletProblemComboBox
            // 
            resources.ApplyResources(this.phoneOrTabletProblemComboBox, "phoneOrTabletProblemComboBox");
            this.phoneOrTabletProblemComboBox.FormattingEnabled = true;
            this.phoneOrTabletProblemComboBox.Name = "phoneOrTabletProblemComboBox";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // laptopProblemComboBox
            // 
            resources.ApplyResources(this.laptopProblemComboBox, "laptopProblemComboBox");
            this.laptopProblemComboBox.FormattingEnabled = true;
            this.laptopProblemComboBox.Name = "laptopProblemComboBox";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // screenProblemComboBox
            // 
            resources.ApplyResources(this.screenProblemComboBox, "screenProblemComboBox");
            this.screenProblemComboBox.FormattingEnabled = true;
            this.screenProblemComboBox.Name = "screenProblemComboBox";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // computerProblemComboBox
            // 
            resources.ApplyResources(this.computerProblemComboBox, "computerProblemComboBox");
            this.computerProblemComboBox.FormattingEnabled = true;
            this.computerProblemComboBox.Name = "computerProblemComboBox";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // adminRadioBtn
            // 
            resources.ApplyResources(this.adminRadioBtn, "adminRadioBtn");
            this.adminRadioBtn.Checked = true;
            this.adminRadioBtn.Name = "adminRadioBtn";
            this.adminRadioBtn.TabStop = true;
            this.adminRadioBtn.UseVisualStyleBackColor = true;
            this.adminRadioBtn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.adminRadioBtn_MouseClick);
            // 
            // viewRadioBtn
            // 
            this.viewRadioBtn.AutoCheck = false;
            resources.ApplyResources(this.viewRadioBtn, "viewRadioBtn");
            this.viewRadioBtn.Name = "viewRadioBtn";
            this.viewRadioBtn.TabStop = true;
            this.viewRadioBtn.UseVisualStyleBackColor = true;
            this.viewRadioBtn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.viewRadioBtn_MouseClick);
            // 
            // modifyRadioBtn
            // 
            this.modifyRadioBtn.AutoCheck = false;
            resources.ApplyResources(this.modifyRadioBtn, "modifyRadioBtn");
            this.modifyRadioBtn.Name = "modifyRadioBtn";
            this.modifyRadioBtn.TabStop = true;
            this.modifyRadioBtn.UseVisualStyleBackColor = true;
            this.modifyRadioBtn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.modifyRadioBtn_MouseClick);
            // 
            // addButton
            // 
            this.addButton.AutoCheck = false;
            resources.ApplyResources(this.addButton, "addButton");
            this.addButton.Name = "addButton";
            this.addButton.TabStop = true;
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.addButton_MouseClick);
            // 
            // screenProbTextBox
            // 
            resources.ApplyResources(this.screenProbTextBox, "screenProbTextBox");
            this.screenProbTextBox.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.screenProbTextBox.Name = "screenProbTextBox";
            this.screenProbTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.screenProbTextBox_MouseClick);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Menu;
            this.groupBox1.Controls.Add(this.adminRadioBtn);
            this.groupBox1.Controls.Add(this.viewRadioBtn);
            this.groupBox1.Controls.Add(this.modifyRadioBtn);
            this.groupBox1.Controls.Add(this.addButton);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // AdminPage
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Controls.Add(this.actionTookAddBtn);
            this.Controls.Add(this.actionTookRemoveBtn);
            this.Controls.Add(this.actionTookTextBox);
            this.Controls.Add(this.actionTookComboBox);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.orderTypeAddBtn);
            this.Controls.Add(this.orderTypeRemoveBtn);
            this.Controls.Add(this.orderTypeTextBox);
            this.Controls.Add(this.orderTypeComboBox);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.phoneOrTabProbAddBtn);
            this.Controls.Add(this.phoneOrTabProbRemoveBtn);
            this.Controls.Add(this.laptopProbAddBtn);
            this.Controls.Add(this.laptopProbRemoveBtn);
            this.Controls.Add(this.screenProbAddBtn);
            this.Controls.Add(this.screenProbRemoveBtn);
            this.Controls.Add(this.computerProbAddBtn);
            this.Controls.Add(this.computerProbRemoveBtn);
            this.Controls.Add(this.phoneOrTabTextBox);
            this.Controls.Add(this.laptopProbTextBox);
            this.Controls.Add(this.computerProbTextBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.phoneOrTabletProblemComboBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.laptopProblemComboBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.screenProblemComboBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.computerProblemComboBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.screenProbTextBox);
            this.Controls.Add(this.groupBox1);
            this.Name = "AdminPage";
            this.Load += new System.EventHandler(this.AdminPage_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button actionTookAddBtn;
        private System.Windows.Forms.Button actionTookRemoveBtn;
        private System.Windows.Forms.TextBox actionTookTextBox;
        private System.Windows.Forms.ComboBox actionTookComboBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button orderTypeAddBtn;
        private System.Windows.Forms.Button orderTypeRemoveBtn;
        private System.Windows.Forms.TextBox orderTypeTextBox;
        private System.Windows.Forms.ComboBox orderTypeComboBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button phoneOrTabProbAddBtn;
        private System.Windows.Forms.Button phoneOrTabProbRemoveBtn;
        private System.Windows.Forms.Button laptopProbAddBtn;
        private System.Windows.Forms.Button laptopProbRemoveBtn;
        private System.Windows.Forms.Button screenProbAddBtn;
        private System.Windows.Forms.Button screenProbRemoveBtn;
        private System.Windows.Forms.Button computerProbAddBtn;
        private System.Windows.Forms.Button computerProbRemoveBtn;
        private System.Windows.Forms.TextBox phoneOrTabTextBox;
        private System.Windows.Forms.TextBox laptopProbTextBox;
        private System.Windows.Forms.TextBox computerProbTextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox phoneOrTabletProblemComboBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox laptopProblemComboBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox screenProblemComboBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox computerProblemComboBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton adminRadioBtn;
        private System.Windows.Forms.RadioButton viewRadioBtn;
        private System.Windows.Forms.RadioButton modifyRadioBtn;
        private System.Windows.Forms.RadioButton addButton;
        private System.Windows.Forms.TextBox screenProbTextBox;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}